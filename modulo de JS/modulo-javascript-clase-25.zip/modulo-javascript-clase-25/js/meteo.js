// https://api.openweathermap.org/data/2.5/weather

import { request } from "./utils.js"

const WEATHER_URL = 'https://api.openweathermap.org/data/2.5/weather'
const appid = ''
const units = 'metric'
const lang = 'es'
const getWeather = async (lat, lon) => { }

export { getWeather }

